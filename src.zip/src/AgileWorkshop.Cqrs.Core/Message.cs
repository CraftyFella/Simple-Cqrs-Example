namespace AgileWorkshop.Cqrs.Core
{
	public interface Message
	{
	}
}

