using System;

namespace AgileWorkshop.Cqrs.Core
{
	[Serializable]
	public class Command : Message
	{
	}
}
