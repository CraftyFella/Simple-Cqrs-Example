﻿namespace AgileWorkshop.Cqrs.EventStore
{
	using System;

	public class AggregateNotFoundException : Exception
	{
	}
}