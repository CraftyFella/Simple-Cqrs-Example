﻿namespace AgileWorkshop.Cqrs.EventStore
{
	using System;

	public class ConcurrencyException : Exception
	{
	}
}